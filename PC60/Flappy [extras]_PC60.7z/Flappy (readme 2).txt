TITLE  : FLAPPY
MAKER  : dB-SOFT
TYPE   : Puzzle
OPTION : Mode 5,Page 2
�@�@�@ cload,run
