
#ifdef __cplusplus
extern "C" {
#endif

void initgetfile(OEMCHAR *path, UINT size);
void initload(void);
void initsave(void);

#ifdef __cplusplus
}
#endif

