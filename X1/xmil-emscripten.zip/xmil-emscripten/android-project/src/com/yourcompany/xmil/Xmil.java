package com.yourcompany.xmil;
import org.libsdl.app.SDLActivity;
/*
 * A sample wrapper class that just calls SDLActivity
 */
public class Xmil extends SDLActivity
{
}
