
#ifdef __cplusplus
extern "C" {
#endif

void LIBCCALL solvelzx(UINT8 *dst, int dstsize, const UINT8 *src);

#ifdef __cplusplus
}
#endif

