#include	"compiler.h"
#include	"font.h"


#if defined(ADV_SIMULATE)
	UINT8	font_ank[0x800];
#endif

