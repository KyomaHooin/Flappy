
#define fddmtr_initialize()
#define fddmtr_motormove()
#define fddmtr_callback(t)
#define fddmtr_waitsec(v)
#define fddmtr_drvset()
#define	fddmtr_isbusy()		(FALSE)

