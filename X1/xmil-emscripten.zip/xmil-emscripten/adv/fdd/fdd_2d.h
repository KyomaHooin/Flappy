
#ifdef __cplusplus
extern "C" {
#endif

BRESULT fdd2d_set(FDDFILE fdd, const UINT8 *romptr, UINT romsize);
void fdd2d_eject(FDDFILE fdd);

#ifdef __cplusplus
}
#endif

