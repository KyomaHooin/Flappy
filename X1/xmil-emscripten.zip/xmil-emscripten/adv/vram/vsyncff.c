#include	"compiler.h"
#include	"vsyncff.h"


// �_�~�[

void vsyncff_init(void) {
}

void vsyncff_turn(REG8 en) {
}

