
#ifdef __cplusplus
extern "C" {
#endif

void vsyncff_init(void);
void vsyncff_turn(REG8 en);

#ifdef __cplusplus
}
#endif

