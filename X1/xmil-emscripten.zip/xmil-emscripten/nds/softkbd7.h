
void softkbd7_initialize(void);
bool softkbd7_down(int x, int y);
bool softkbd7_up(void);
void softkbd7_sync(void);

