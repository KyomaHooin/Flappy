
#ifdef __cplusplus
extern "C"
{
#endif

void pal_update1(const UINT8 *rgbp);
void pal_update();

void pal_reset();

#ifdef __cplusplus
}
#endif

#define	pal_eventclear()

