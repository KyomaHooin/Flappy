
#if defined(__cplusplus)
extern "C"
{
#endif	// defined(__cplusplus)

void ndscore_timer3init();
void ndscore_timer3int();
void ndscore_sleep(unsigned int uCount);
void ndscore_rest(unsigned int uCount);
unsigned int ndscore_gettick();

#if defined(__cplusplus)
}
#endif	// defined(__cplusplus)

