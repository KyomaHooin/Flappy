#include "compiler.h"
#include "libnds.h"


int main()
{
	return nds9main();
}

