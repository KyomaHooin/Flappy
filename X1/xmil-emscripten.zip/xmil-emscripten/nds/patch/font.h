
#define	FONTX1_LR			0x10000
#define	FONTX1T_LR			0x20000

#if defined(__cplusplus)
extern "C"
{
#endif	/* defined(__cplusplus) */

extern	UINT8	font_ank[];

#if defined(__cplusplus)
}
#endif	/* defined(__cplusplus) */

#define	font_txt			__extromimage.txt
#define	font_knjx1			__extromimage.knjx1
#define	font_knjx1t			__extromimage.knjx1t

#define font_load(f, p)		do { } while(0)
