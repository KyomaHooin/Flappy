
extern	bool	__nds_avail;
extern	HWND	__nds_hWnd;

bool ndssys_task();


static inline void readUserSettings() { }

