#include "compiler.h"
#include "libnds.h"

tagNdsSoundReg s_ndssound;

