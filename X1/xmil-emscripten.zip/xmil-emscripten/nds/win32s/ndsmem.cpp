#include "compiler.h"
#include "libnds.h"

	unsigned char	__ipcbase[0x1000];

