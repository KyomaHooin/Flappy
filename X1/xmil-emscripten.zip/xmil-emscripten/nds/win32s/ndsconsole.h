
void consoleInitDefault(u16* map, u16* charBase, u8 bitDepth);
void iprintf(const char *lpcszFormat, ...);

