
void swiWaitForVBlank(void);

