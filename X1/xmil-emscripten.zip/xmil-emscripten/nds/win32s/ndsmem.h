
extern unsigned char	__ipcbase[0x1000];

#define	IPCBASE			__ipcbase

