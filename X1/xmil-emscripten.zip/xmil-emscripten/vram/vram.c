#include	"compiler.h"
#include	"vram.h"


	TRAM	tram[0x800];
	UINT8	gram[GRAM_SIZE];

