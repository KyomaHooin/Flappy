
#ifdef __cplusplus
extern "C" {
#endif

void newdisk_fdd(const OEMCHAR *fname, REG8 type, const OEMCHAR *label);

#ifdef __cplusplus
}
#endif

