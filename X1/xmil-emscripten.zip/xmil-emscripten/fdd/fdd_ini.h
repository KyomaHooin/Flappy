
#ifdef __cplusplus
extern "C" {
#endif

BOOL is_d8ufile(const OEMCHAR *fname);
BRESULT fdd_ini(const OEMCHAR *filename);

#ifdef __cplusplus
}
#endif

